using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Http;
using System.Linq;
using Chefs.Models;

namespace Chefs.Controllers
{     
    public class Homecontroller : Controller  
    {
        private MyContext dbContext;
 
        public Homecontroller(MyContext context)
        {
            dbContext = context;
        }
        
        [HttpGet]     
        [Route("")]    
        public IActionResult Index()
        {
            
            List<Chef> ThoseChefs = dbContext.Chefs.Include(user => user.CreatedRecipies)
                                    .ToList();
            return View(ThoseChefs);
        }

        [HttpGet]
        [Route("NewChef")]
        public IActionResult NewChef()
        {
            

            return View();
        }

        [HttpPost]
        [Route("CreateChef")]
        public IActionResult CreateChef(Chef newChef)
        {
            
            dbContext.Add(newChef);
            dbContext.SaveChanges();

            return Redirect("/");
        }
        
        [HttpGet]     
        [Route("ShowDishes")]    
        public IActionResult ShowDishes()
        {
            
            List<Recipie> ThoseRecipies = dbContext.Recipies.ToList();
            return View(ThoseRecipies);
        }

        [HttpGet]
        [Route("NewRecipie")]
        public IActionResult NewRecipie()
        {
            ViewBag.AllChefs = dbContext.Chefs.OrderByDescending(c => c.LastName).ToList();

            return View();
        }

        [HttpPost]
        [Route("CreateRecipie")]
        public IActionResult CreateRecipie(Recipie newRecipie)
        {
            
            dbContext.Add(newRecipie);
            dbContext.SaveChanges();

            return Redirect("ShowDishes");
        }
    }
}

