﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace chefs.Migrations
{
    public partial class Recipies : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Recipie_Chefs_ChefId",
                table: "Recipie");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Recipie",
                table: "Recipie");

            migrationBuilder.RenameTable(
                name: "Recipie",
                newName: "Recipies");

            migrationBuilder.RenameIndex(
                name: "IX_Recipie_ChefId",
                table: "Recipies",
                newName: "IX_Recipies_ChefId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Recipies",
                table: "Recipies",
                column: "RecipieId");

            migrationBuilder.AddForeignKey(
                name: "FK_Recipies_Chefs_ChefId",
                table: "Recipies",
                column: "ChefId",
                principalTable: "Chefs",
                principalColumn: "ChefId",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Recipies_Chefs_ChefId",
                table: "Recipies");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Recipies",
                table: "Recipies");

            migrationBuilder.RenameTable(
                name: "Recipies",
                newName: "Recipie");

            migrationBuilder.RenameIndex(
                name: "IX_Recipies_ChefId",
                table: "Recipie",
                newName: "IX_Recipie_ChefId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Recipie",
                table: "Recipie",
                column: "RecipieId");

            migrationBuilder.AddForeignKey(
                name: "FK_Recipie_Chefs_ChefId",
                table: "Recipie",
                column: "ChefId",
                principalTable: "Chefs",
                principalColumn: "ChefId",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
